# Streamlit UI for Research Agent — drop-in update

## What's in here

```
app/
  ui/
    __init__.py
    api_client.py      # NEW — wraps the 4 backend endpoints with requests
    state.py            # NEW — st.session_state schema + helpers
    components.py        # NEW — chat bubble + route/score badge rendering
    streamlit_app.py     # NEW — the actual UI, entry point
  db/
    model.py             # UPDATED — Message now stores route + final_score
  api/
    routes.py            # UPDATED — persists route/score, returns them too
```

Copy the `app/` folder into your project root, merging it with your
existing `app/` (it will only add `app/ui/` and overwrite `model.py` /
`routes.py`).

> Heads up: `model.py` and `routes.py` here overwrite the versions you
> shared earlier. If you've changed either file since, apply just the
> diff manually instead of overwriting:
> - `Message` gains two columns: `route: Mapped[str | None]` and
>   `final_score: Mapped[float | None]`.
> - `MessageOut` gains `route: str | None = None` and
>   `score: float | None = None`.
> - the `/chat` route passes `route=route, final_score=score` into the
>   assistant `Message(...)` it persists.
> - `/messages` returns `route=m.route, score=m.final_score` per row.

## One-time DB step (important)

Your `init_db()` uses `Base.metadata.create_all`, which only creates
*missing tables* — it won't add new columns to a `messages` table that
already exists. Pick one:

**Easiest (dev, loses existing history):**
```sql
DROP TABLE messages CASCADE;
```
Then restart the backend — `create_all` will recreate it with the new
columns.

**Keeps history:**
```sql
ALTER TABLE messages ADD COLUMN route VARCHAR(10);
ALTER TABLE messages ADD COLUMN final_score FLOAT;
```

## Dependencies

`streamlit` is already in your `requirements.txt`. The UI also needs
`requests` (already pulled in transitively, but worth adding explicitly
since the UI now depends on it directly):

```
uv add requests
# or: pip install requests
```

## Running it

Two processes, in two terminals:

```bash
# Terminal 1 — backend (after applying the Windows event-loop fix)
uv run python main.py

# Terminal 2 — UI
streamlit run app/ui/streamlit_app.py
```

Streamlit opens at `http://localhost:8501`. The backend URL is
configurable in the sidebar (⚙️ Connection settings) in case you run it
on a different host/port — defaults to `http://localhost:8020` to match
your `main.py`.

## What you get

- **Sidebar**: create new chats, switch between existing sessions, and
  upload a PDF scoped to whichever session is active.
- **Main panel**: a real `st.chat_message` / `st.chat_input` conversation.
  Each assistant reply shows a badge for which route the supervisor took
  (📄 PDF / 🌐 Web / 🧩 PDF + Web) and the critic's score, both of which now
  survive a page reload.
- **Resilience**: every API call goes through `api_client.py`, which
  catches connection errors/timeouts and surfaces them as a friendly
  `st.error` instead of a stack trace — useful since you'll occasionally
  forget to start the backend first.

## Known gaps / natural next steps

- `/chat` is a single blocking call, so the UI just shows a spinner for
  the whole search → write → critique loop (can be 10s–2min). Streaming
  intermediate node updates would need `graph.astream()` on the backend
  plus an SSE/WebSocket endpoint — bigger change, worth doing once the
  basic flow feels solid.
- No "delete session" button yet — would need a `DELETE /sessions/{sid}`
  route (the cascade delete is already set up on the `Session` model, so
  the backend side is a few lines).
- Session titles are still always "New chat". Auto-titling from the first
  user message would need a small `PATCH /sessions/{sid}` endpoint, or
  could be derived client-side.
