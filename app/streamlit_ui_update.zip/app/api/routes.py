"""FastAPI routes for the research chatbot.

A "session" == a chat thread. Its id is the ``thread_id`` used everywhere
(Qdrant PDF scoping + LangGraph conversation memory).

Endpoints:
  POST /sessions                  create a chat session
  GET  /sessions                  list sessions
  POST /sessions/{sid}/upload     upload + index a PDF for the session
  POST /sessions/{sid}/chat       ask a question (supervisor routes it)
  GET  /sessions/{sid}/messages   full chat history

UPDATED: ``MessageOut`` now includes ``route``/``score`` (populated for
assistant messages) so the Streamlit UI can render badges even after a
page reload, not just on the live response.
"""
from __future__ import annotations

import asyncio

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import async_session
from app.db.model import Document as DocRow, Message, Session as ChatSession
from app.Agents.pdf_reader import ingest_pdf
from app.state.schema import ResearchState

router = APIRouter()


# ── DB dependency ────────────────────────────────────────────────────────────
async def get_db() -> AsyncSession:
    async with async_session() as db:
        yield db


# ── Schemas ──────────────────────────────────────────────────────────────────
class SessionOut(BaseModel):
    id: str
    title: str


class ChatRequest(BaseModel):
    query: str


class ChatResponse(BaseModel):
    session_id: str
    route: str | None
    answer: str
    score: float | None


class MessageOut(BaseModel):
    role: str
    content: str
    route: str | None = None
    score: float | None = None


# ── Helpers ──────────────────────────────────────────────────────────────────
async def _get_session_or_404(db: AsyncSession, sid: str) -> ChatSession:
    session = await db.get(ChatSession, sid)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return session


# ── Endpoints ────────────────────────────────────────────────────────────────
@router.post("/sessions", response_model=SessionOut)
async def create_session(db: AsyncSession = Depends(get_db)):
    session = ChatSession()
    db.add(session)
    await db.commit()
    await db.refresh(session)
    return SessionOut(id=session.id, title=session.title)


@router.get("/sessions", response_model=list[SessionOut])
async def list_sessions(db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(select(ChatSession))).scalars().all()
    return [SessionOut(id=s.id, title=s.title) for s in rows]


@router.post("/sessions/{sid}/upload")
async def upload_pdf(
    sid: str,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    await _get_session_or_404(db, sid)

    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")

    file_bytes = await file.read()
    # ingest_pdf is CPU-bound (embeddings) -> run off the event loop.
    result = await asyncio.to_thread(
        ingest_pdf, file_bytes, sid, file.filename
    )

    db.add(DocRow(session_id=sid, filename=result["filename"], chunks=result["chunks"]))
    await db.commit()
    return result


@router.post("/sessions/{sid}/chat", response_model=ChatResponse)
async def chat(
    sid: str,
    body: ChatRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    await _get_session_or_404(db, sid)

    # Persist the user's message.
    db.add(Message(session_id=sid, role="user", content=body.query))
    await db.commit()

    # Run the graph (supervisor decides pdf/web/both). thread_id = session id.
    graph = request.app.state.graph
    initial_state: ResearchState = {
        "topic":            body.query,
        "thread_id":        sid,
        "revision_count":   0,
        "revision_history": [],
    }
    final_state = await graph.ainvoke(
        initial_state,
        config={"configurable": {"thread_id": sid}},
    )

    answer = final_state.get("report", "")
    route = final_state.get("route")
    score = final_state.get("final_score")

    # Persist the assistant's answer, along with the route + score so the
    # UI can still show them after a reload.
    db.add(Message(
        session_id=sid,
        role="assistant",
        content=answer,
        route=route,
        final_score=score,
    ))
    await db.commit()

    return ChatResponse(session_id=sid, route=route, answer=answer, score=score)


@router.get("/sessions/{sid}/messages", response_model=list[MessageOut])
async def get_messages(sid: str, db: AsyncSession = Depends(get_db)):
    await _get_session_or_404(db, sid)
    rows = (await db.execute(
        select(Message).where(Message.session_id == sid).order_by(Message.created_at)
    )).scalars().all()
    return [
        MessageOut(role=m.role, content=m.content, route=m.route, score=m.final_score)
        for m in rows
    ]
