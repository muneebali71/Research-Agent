"""Thin HTTP client wrapping the Research Agent FastAPI backend.

Every Streamlit page should go through these functions instead of calling
``requests`` directly, so there is a single place that knows the API
contract (paths, payload shapes, timeouts).
"""
from __future__ import annotations

import requests

DEFAULT_BASE_URL = "http://localhost:8020"
DEFAULT_TIMEOUT = 10   # fast calls: create/list sessions, fetch messages
UPLOAD_TIMEOUT = 120   # PDF chunking + embedding can take a while
CHAT_TIMEOUT = 180     # full search -> write -> critic/revise pipeline


class ApiError(Exception):
    """Raised whenever the backend is unreachable or returns an error."""


def _request(method: str, url: str, **kwargs):
    try:
        return requests.request(method, url, **kwargs)
    except requests.exceptions.Timeout as exc:
        raise ApiError(
            "The backend took too long to respond. It may still be "
            "working in the background — try again in a bit."
        ) from exc
    except requests.exceptions.RequestException as exc:
        raise ApiError(
            f"Could not reach the backend at {url}. Is `uv run python "
            f"main.py` running? ({exc})"
        ) from exc


def _handle(resp: requests.Response):
    try:
        resp.raise_for_status()
    except requests.HTTPError as exc:
        detail = None
        try:
            detail = resp.json().get("detail")
        except Exception:
            pass
        raise ApiError(detail or str(exc)) from exc
    return resp.json()


def create_session(base_url: str) -> dict:
    resp = _request("POST", f"{base_url}/sessions", timeout=DEFAULT_TIMEOUT)
    return _handle(resp)


def list_sessions(base_url: str) -> list[dict]:
    resp = _request("GET", f"{base_url}/sessions", timeout=DEFAULT_TIMEOUT)
    return _handle(resp)


def get_messages(base_url: str, session_id: str) -> list[dict]:
    resp = _request(
        "GET", f"{base_url}/sessions/{session_id}/messages", timeout=DEFAULT_TIMEOUT
    )
    return _handle(resp)


def upload_pdf(base_url: str, session_id: str, filename: str, file_bytes: bytes) -> dict:
    files = {"file": (filename, file_bytes, "application/pdf")}
    resp = _request(
        "POST",
        f"{base_url}/sessions/{session_id}/upload",
        files=files,
        timeout=UPLOAD_TIMEOUT,
    )
    return _handle(resp)


def send_chat(base_url: str, session_id: str, query: str) -> dict:
    resp = _request(
        "POST",
        f"{base_url}/sessions/{session_id}/chat",
        json={"query": query},
        timeout=CHAT_TIMEOUT,
    )
    return _handle(resp)
