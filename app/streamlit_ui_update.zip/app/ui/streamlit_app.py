"""Streamlit front-end for the Multi-Agent Research & Report Generation
chatbot.

Run with (from the project root, with the FastAPI backend already running
via ``uv run python main.py``):

    streamlit run app/ui/streamlit_app.py
"""
from __future__ import annotations

import streamlit as st

from app.ui.api_client import (
    ApiError,
    create_session,
    get_messages,
    list_sessions,
    send_chat,
    upload_pdf,
)
from app.ui.components import render_badges, render_message
from app.ui.state import current_session_title, init_state, set_current_session

st.set_page_config(page_title="Research Agent", page_icon="🔎", layout="wide")
init_state()


# ── Sidebar ──────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🔎 Research Agent")
    st.caption("Multi-agent research & report chatbot")

    with st.expander("⚙️ Connection settings"):
        st.session_state.api_base_url = st.text_input(
            "Backend URL", value=st.session_state.api_base_url
        )

    if st.button("➕ New chat", use_container_width=True, type="primary"):
        try:
            session = create_session(st.session_state.api_base_url)
        except ApiError as exc:
            st.error(str(exc))
        else:
            st.session_state.sessions.insert(0, session)
            set_current_session(session["id"])
            st.rerun()

    st.divider()

    # Load the session list once per app load (and right after creating one)
    if not st.session_state.sessions_loaded:
        try:
            st.session_state.sessions = list_sessions(st.session_state.api_base_url)
        except ApiError as exc:
            st.error(str(exc))
        else:
            st.session_state.sessions_loaded = True

    st.caption("Sessions")
    if not st.session_state.sessions:
        st.caption("No sessions yet — create one above.")
    for s in st.session_state.sessions:
        is_active = s["id"] == st.session_state.current_session_id
        label = ("▶  " if is_active else "    ") + (s.get("title") or "New chat")
        if st.button(label, key=f"sess-{s['id']}", use_container_width=True):
            set_current_session(s["id"])
            st.rerun()

    st.divider()

    # ── PDF upload, scoped to the active session ──
    st.caption("Documents")
    if st.session_state.current_session_id is None:
        st.info("Start or select a chat to upload a PDF.")
    else:
        sid = st.session_state.current_session_id
        pdf_file = st.file_uploader("Upload a PDF", type="pdf")
        if pdf_file is not None and st.button(
            "📤 Index PDF", use_container_width=True
        ):
            with st.spinner("Chunking and embedding the PDF..."):
                try:
                    result = upload_pdf(
                        st.session_state.api_base_url,
                        sid,
                        pdf_file.name,
                        pdf_file.getvalue(),
                    )
                except ApiError as exc:
                    st.error(str(exc))
                else:
                    st.session_state.uploaded_files.setdefault(sid, []).append(
                        result["filename"]
                    )
                    st.success(
                        f"Indexed {result['chunks']} chunks from "
                        f"{result['filename']}"
                    )

        for fname in st.session_state.uploaded_files.get(sid, []):
            st.markdown(f"📄 {fname}")


# ── Main panel ───────────────────────────────────────────────────────────
if st.session_state.current_session_id is None:
    st.title("Welcome 👋")
    st.write(
        "Create a new chat from the sidebar to get started. You can ask "
        "a general research question, or upload a PDF first and ask "
        "about it — the supervisor agent decides whether to answer from "
        "the web, the PDF, or both."
    )
else:
    sid = st.session_state.current_session_id
    st.title(current_session_title() or "Chat")

    # Lazily load history the first time we land on this session
    if not st.session_state.messages:
        try:
            st.session_state.messages = get_messages(
                st.session_state.api_base_url, sid
            )
        except ApiError as exc:
            st.error(str(exc))

    for msg in st.session_state.messages:
        render_message(msg)

    query = st.chat_input("Ask a question...")
    if query:
        st.session_state.messages.append({"role": "user", "content": query})
        render_message({"role": "user", "content": query})

        with st.chat_message("assistant"):
            with st.spinner("Researching — this can take a minute..."):
                try:
                    result = send_chat(st.session_state.api_base_url, sid, query)
                except ApiError as exc:
                    st.error(str(exc))
                else:
                    st.markdown(result["answer"])
                    render_badges(result.get("route"), result.get("score"))
                    st.session_state.messages.append(
                        {
                            "role": "assistant",
                            "content": result["answer"],
                            "route": result.get("route"),
                            "score": result.get("score"),
                        }
                    )
