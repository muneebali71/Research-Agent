"""Streamlit ``st.session_state`` initialization + small helpers.

Keeping this separate from streamlit_app.py makes the state shape explicit
and easy to extend later (e.g. adding auth, themes, multi-tab support).
"""
from __future__ import annotations

import streamlit as st

from app.ui.api_client import DEFAULT_BASE_URL


def init_state() -> None:
    defaults = {
        "api_base_url": DEFAULT_BASE_URL,
        "sessions": [],          # [{"id": ..., "title": ...}, ...]
        "current_session_id": None,
        "messages": [],          # [{"role", "content", "route"?, "score"?}, ...]
        "uploaded_files": {},    # session_id -> [filenames]
        "sessions_loaded": False,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def current_session_title() -> str | None:
    sid = st.session_state.current_session_id
    for s in st.session_state.sessions:
        if s["id"] == sid:
            return s.get("title")
    return None


def set_current_session(session_id: str) -> None:
    """Switch the active session and force a reload of its history."""
    st.session_state.current_session_id = session_id
    st.session_state.messages = []
